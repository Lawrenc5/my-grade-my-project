import express from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import OpenAI from "openai";
import path from "node:path";
import { fileURLToPath } from "node:url";

const app = express();
const root = path.dirname(fileURLToPath(import.meta.url));
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "10kb" }));
const limiter = rateLimit({ windowMs: 60_000, limit: 10, standardHeaders: "draft-8", legacyHeaders: false });
const ai = process.env.OPENAI_API_KEY ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY }) : null;

app.get("/api/health", (_req,res)=>res.json({ok:true, aiConfigured:Boolean(ai)}));
app.post("/api/tutor", limiter, async (req,res)=>{
  try {
    if (!ai) return res.status(503).json({error:"AI Tutor is not configured on the server yet."});
    const {message, grade="Grade 7", history=[]} = req.body ?? {};
    if (typeof message !== "string" || !message.trim() || message.length > 1500)
      return res.status(400).json({error:"Enter a question up to 1,500 characters."});
    const validGrade = ["Grade 7","Grade 8","Grade 9"].includes(grade) ? grade : "Grade 7";
    const recent = Array.isArray(history) ? history.slice(-8).filter(x =>
      x && ["user","assistant"].includes(x.role) && typeof x.content === "string" && x.content.length <= 1500
    ) : [];
    const response = await ai.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5.5",
      instructions: `You are My Grade AI Tutor for Kenyan junior school Grades 7-9. Explain concepts in clear, age-appropriate language. Guide learners step by step instead of simply doing all their work. Create original revision questions when asked. Be respectful and encouraging. Do not request or repeat private details such as names, addresses, phone numbers or passwords. Do not provide graphic, dangerous or age-inappropriate content. For teacher requests, provide draft ideas that require teacher review. Do not claim content is official KICD material unless verified source material is supplied.`,
      input: [...recent, {role:"user",content:`Context: ${validGrade}. Question: ${message.trim()}`}],
      max_output_tokens: 650,
      store: false
    });
    res.json({reply: response.output_text || "Please try asking that another way."});
  } catch (e) {
    console.error("Tutor error:", e?.message || "unknown");
    res.status(502).json({error:"The AI Tutor could not answer just now."});
  }
});
app.use(express.static(path.join(root,"public")));
app.get("*",(_req,res)=>res.sendFile(path.join(root,"public","index.html")));
app.listen(process.env.PORT||3000,()=>console.log("My Grade, My Project running"));
