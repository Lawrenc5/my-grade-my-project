# My Grade, My Project — AI Tutor Source Code

## Included
- Learner dashboard and Grade 7-9 selector
- Classroom sample lessons, revision quiz, project planner and progress tracking
- Teacher lesson-plan draft tool
- AI Tutor interface
- Node.js backend endpoint that calls the OpenAI Responses API
- Server-side API key, request size validation and basic rate limiting
- PWA manifest and offline app-shell cache

## Run on a computer
Requires Node.js 20+.
1. Extract this ZIP and open a terminal in the folder.
2. Run `npm install`.
3. Copy `.env.example` to `.env`.
4. Add your API key to `.env` as `OPENAI_API_KEY=...`.
5. Run `npm start`.
6. Open `http://localhost:3000`.

Never put the API key in browser JavaScript, HTML, Android app code or a public repository. It belongs only on the server. Official guidance: https://developers.openai.com/api/docs/guides/api-keys

## Android
This is source code, not an APK. To use the live AI Tutor on Android, deploy the Node.js server to HTTPS hosting that supports environment variables, then open its HTTPS address in Chrome. A static HTML preview alone cannot run the AI endpoint. Chrome may offer an install/add-to-home-screen option.

## Important limitations
This is a development MVP, not a production-ready national platform. It does not yet include secure user accounts, school/class separation, cloud learner records, cross-device sync, teacher permissions or production abuse monitoring. Add authentication, school-level access controls, usage limits and privacy review before real school deployment. Sample curriculum content must be checked against current official KICD designs. Avoid entering identifiable learner data.
